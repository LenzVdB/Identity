using System;

namespace Onderzoekstopics
{
    public class Class1
    {
    }
}