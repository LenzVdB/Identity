using System;

namespace DAL
{
    public class Class1
    {
    }
}